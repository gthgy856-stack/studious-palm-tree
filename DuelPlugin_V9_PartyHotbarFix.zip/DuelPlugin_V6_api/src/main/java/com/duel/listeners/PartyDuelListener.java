package com.duel.listeners;

import com.duel.DuelPlugin;
import com.duel.models.PartyDuelSession;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerRespawnEvent;

public class PartyDuelListener implements Listener {

    private final DuelPlugin plugin;

    /** مكان موت اللاعب داخل عالم المباراة */
    private final java.util.Map<java.util.UUID, Location> deathLocations = new java.util.HashMap<>();

    public PartyDuelListener(DuelPlugin plugin) {
        this.plugin = plugin;
    }

    // ──────────────────────────────────────────
    //  موت → spectator (أو نهاية مباراة)
    // ──────────────────────────────────────────

    @EventHandler(priority = EventPriority.HIGH)
    public void onDeath(PlayerDeathEvent event) {
        Player dead = event.getEntity();
        if (!plugin.getPartyDuelManager().isInPartyDuel(dead)) return;

        PartyDuelSession session = plugin.getPartyDuelManager().getSession(dead);
        if (session == null || session.getState() != PartyDuelSession.State.FIGHTING) return;

        // احفظ مكان الموت + تخطّي شاشة الموت (respawn تلقائي بعد tick)
        deathLocations.put(dead.getUniqueId(), dead.getLocation().clone());
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            if (dead.isOnline() && dead.isDead()) dead.spigot().respawn();
        }, 1L);

        // إلغاء الـ drops ورسالة الموت
        event.setDeathMessage(null);
        event.getDrops().clear();
        event.setDroppedExp(0);

        // سجّل الموت في الجلسة
        plugin.getPartyDuelManager().onPlayerDeath(dead);
    }

    // ──────────────────────────────────────────
    //  Respawn → ابقِه spectator في نفس العالم
    // ──────────────────────────────────────────

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onRespawn(PlayerRespawnEvent event) {
        Player p = event.getPlayer();
        Location death = deathLocations.remove(p.getUniqueId());
        PartyDuelSession session = plugin.getPartyDuelManager().getSession(p);
        if (session == null) return;

        org.bukkit.World duelWorld = org.bukkit.Bukkit.getWorld(session.getCopiedWorldName());
        if (duelWorld == null) return;

        // مكان الموت داخل عالم المباراة، وإلا (فويد/عالم مختلف) سبون العالم
        Location respawnLoc = death;
        if (respawnLoc == null || respawnLoc.getWorld() == null
                || !respawnLoc.getWorld().equals(duelWorld)
                || respawnLoc.getY() < duelWorld.getMinHeight()) {
            respawnLoc = duelWorld.getSpawnLocation();
        }
        event.setRespawnLocation(respawnLoc);

        // بعد النقل (tick) → سبكتيت + يتابع أول لاعب حي
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            if (!p.isOnline()) return;
            // سبكتيت حر — بدون ربط الكاميرا بلاعب
            p.setGameMode(GameMode.SPECTATOR);
        }, 1L);
    }

    // ──────────────────────────────────────────
    //  PvP — اسمح بالضرر داخل نفس الجلسة فقط
    // ──────────────────────────────────────────

    @EventHandler(priority = EventPriority.HIGH)
    public void onDamage(EntityDamageByEntityEvent event) {
        if (!(event.getEntity()  instanceof Player victim))   return;
        if (!(event.getDamager() instanceof Player attacker)) return;

        boolean aInPartyDuel = plugin.getPartyDuelManager().isInPartyDuel(attacker);
        boolean vInPartyDuel = plugin.getPartyDuelManager().isInPartyDuel(victim);

        // لا أحد في party duel — اتركها للـ DuelListener العادي
        if (!aInPartyDuel && !vInPartyDuel) return;

        // أحدهم في party duel والثاني لا — الغِ
        if (aInPartyDuel != vInPartyDuel) {
            event.setCancelled(true);
            return;
        }

        // كلاهما في party duel — يجب أن يكونا في نفس الجلسة
        PartyDuelSession aSession = plugin.getPartyDuelManager().getSession(attacker);
        PartyDuelSession vSession = plugin.getPartyDuelManager().getSession(victim);

        if (aSession == null || !aSession.equals(vSession)) {
            event.setCancelled(true);
            return;
        }

        // لا يجوز الضرب بين أعضاء نفس الفريق
        if (aSession.getTeamOf(attacker) == aSession.getTeamOf(victim)) {
            event.setCancelled(true);
            return;
        }

        // هل الجلسة في مرحلة القتال؟
        if (aSession.getState() != PartyDuelSession.State.FIGHTING) {
            event.setCancelled(true);
            return;
        }

        // هل الضحية لا تزال حية؟
        if (!aSession.isAlive(victim)) {
            event.setCancelled(true);
            return;
        }

        // كل الشروط مرت — اسمح بالضرر
    }
}
