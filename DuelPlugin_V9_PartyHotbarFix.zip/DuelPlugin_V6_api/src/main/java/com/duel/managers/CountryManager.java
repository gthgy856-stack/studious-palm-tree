package com.duel.managers;

import com.duel.DuelPlugin;
import org.bukkit.entity.Player;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Looks up a player's country (ISO 3166-1 alpha-2 code, e.g. "EG", "US") from
 * their IP address on join, using the free ip-api.com endpoint (no API key
 * needed). Results are cached in memory for the session.
 *
 * NOTE: ip-api.com's free tier is rate-limited to ~45 requests/minute from
 * the SAME server IP. That's plenty for small/medium networks, but on a
 * high-traffic network with lots of joins per minute you may want to switch
 * to an offline database (MaxMind GeoLite2) instead — ask if you want that
 * version built.
 */
public class CountryManager {

    private static final Pattern COUNTRY_CODE_PATTERN =
            Pattern.compile("\"countryCode\"\\s*:\\s*\"([A-Z]{2})\"");
    private static final Pattern STATUS_FAIL_PATTERN =
            Pattern.compile("\"status\"\\s*:\\s*\"fail\"");

    private final DuelPlugin plugin;
    private final Map<java.util.UUID, String> countryCache = new ConcurrentHashMap<>();

    public CountryManager(DuelPlugin plugin) {
        this.plugin = plugin;
    }

    /** Cached lookup — returns null if not looked up yet or lookup failed. */
    public String getCountryCode(java.util.UUID uuid) {
        return countryCache.get(uuid);
    }

    /** Kicks off an async GeoIP lookup for this player and caches the result. */
    public void lookupAsync(Player player) {
        if (!plugin.getConfig().getBoolean("country-flag.enabled", true)) return;

        String ip = player.getAddress() != null && player.getAddress().getAddress() != null
                ? player.getAddress().getAddress().getHostAddress()
                : null;
        if (ip == null || ip.equals("127.0.0.1") || ip.startsWith("192.168.") || ip.startsWith("10.")) {
            // Local/LAN test connection — no public IP to geolocate.
            countryCache.put(player.getUniqueId(), "XX");
            return;
        }

        plugin.getServer().getScheduler().runTaskAsynchronously(plugin, () -> {
            String code = fetchCountryCode(ip);
            countryCache.put(player.getUniqueId(), code != null ? code : "XX");
        });
    }

    public void clear(java.util.UUID uuid) {
        countryCache.remove(uuid);
    }

    private String fetchCountryCode(String ip) {
        int timeout = plugin.getConfig().getInt("country-flag.api-timeout-ms", 3000);
        try {
            URL url = new URL("http://ip-api.com/json/" + ip + "?fields=status,countryCode");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(timeout);
            conn.setReadTimeout(timeout);

            StringBuilder body = new StringBuilder();
            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8))) {
                String line;
                while ((line = reader.readLine()) != null) body.append(line);
            }

            if (STATUS_FAIL_PATTERN.matcher(body).find()) return null;

            Matcher m = COUNTRY_CODE_PATTERN.matcher(body);
            return m.find() ? m.group(1) : null;
        } catch (Exception e) {
            plugin.getLogger().warning("[CountryManager] GeoIP lookup failed for " + ip + ": " + e.getMessage());
            return null;
        }
    }

    /**
     * Converts a 2-letter ISO country code into the actual flag emoji sequence
     * (regional indicator symbols). NOTE: this is NOT what the resource pack
     * uses for rendering — Minecraft's font system maps ONE codepoint to ONE
     * glyph and cannot compose two codepoints into a single flag image the way
     * phone/desktop OS emoji fonts do. Kept here for reference / other uses
     * (e.g. showing the raw emoji in a Discord bridge). For in-game rendering
     * use {@link #toFlagChar(String)} instead.
     */
    public static String toFlagEmoji(String countryCode) {
        if (countryCode == null || countryCode.length() != 2) return "";
        int base = 0x1F1E6; // regional indicator 'A'
        int c1 = base + (Character.toUpperCase(countryCode.charAt(0)) - 'A');
        int c2 = base + (Character.toUpperCase(countryCode.charAt(1)) - 'A');
        return new String(Character.toChars(c1)) + new String(Character.toChars(c2));
    }

    /**
     * Ordered list of countries this plugin ships a flag texture for.
     * Index in this list = which Private Use Area codepoint (starting at
     * U+E000) the resource pack's font/default.json maps to that flag image.
     * Add more codes here (and a matching PNG + font entry) to support more
     * countries later — keep the ORDER stable once players have the pack
     * cached, or codes will shift to the wrong flags.
     */
    public static final String[] SUPPORTED_FLAGS = {
        "EG", "SA", "AE", "KW", "QA", "BH", "OM", "JO", "IQ", "MA",
        "DZ", "TN", "LY", "SY", "LB", "PS", "YE", "SD",
        "US", "GB", "DE", "FR", "BR", "TR", "IN", "RU",
        // ── batch 2 — appended, do not reorder the block above ──────────
        "ES", "IT", "NL", "BE", "PL", "PT", "SE", "NO", "FI", "DK",
        "GR", "UA", "CH", "AT", "IE", "RO", "HU", "CZ",
        "CA", "MX", "AR", "CL", "CO",
        "JP", "CN", "KR", "PK", "BD", "ID", "PH", "VN", "TH", "MY",
        "NG", "ZA", "KE", "ET", "SO",
        "AU", "NZ"
    };

    /**
     * Returns the single Private-Use-Area character mapped to this country's
     * flag texture in the resource pack, or "" if we don't ship that flag
     * (falls back to showing nothing rather than a broken/blank glyph box).
     */
    public static String toFlagChar(String countryCode) {
        if (countryCode == null) return "";
        for (int i = 0; i < SUPPORTED_FLAGS.length; i++) {
            if (SUPPORTED_FLAGS[i].equalsIgnoreCase(countryCode)) {
                return String.valueOf((char) (0xE000 + i));
            }
        }
        return "";
    }
}
